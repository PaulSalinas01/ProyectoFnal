package com.saucelabs;

import com.aventstack.extentreports.Status;
import com.saucelabs.helpers.ScreenShotHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.concurrent.TimeUnit;

public class CarritoCompras extends BasePagina {
    private final By pedidoBtn = By.xpath("//button[@class='btn btn-success']");
    private final By nameLabel = By.xpath("//input[@id='name']");
    private final By countryLabel = By.xpath("//input[@id='country']");
    private final By cityLabel = By.xpath("//input[@id='city']");
    private final By creditCardLabel = By.xpath("//input[@id='card']");
    private final By MonthLabel = By.xpath("//input[@id='month']");
    private final By YearLabel = By.xpath("//input[@id='year']");
    private final By continuarButton = By.xpath("//button[@onclick='purchaseOrder()'] ");
    private final By aceptarBtn = By.xpath("//button[@class='confirm btn btn-lg btn-primary']");


    public void compraProducto() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.elementToBeClickable(pedidoBtn));
        Assert.assertEquals(driver.findElement(pedidoBtn).getText(), "Place Order");
        wait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("//*[@id=\"tbodyid\"]/tr/td[2]"), "MacBook Pro"));
        driver.findElement(pedidoBtn).click();
    }

    public void llenadoFormulario(String name, String country, String city, String creditCard, String Month, String Year) {
        WebDriverWait wait2 = new WebDriverWait(driver, 10);
        wait2.until(ExpectedConditions.elementToBeClickable(nameLabel));
        driver.findElement(this.nameLabel).sendKeys(name);
        driver.findElement(this.countryLabel).sendKeys(country);
        driver.findElement(this.cityLabel).sendKeys(city);
        driver.findElement(this.creditCardLabel).sendKeys(creditCard);
        driver.findElement(this.MonthLabel).sendKeys(Month);
        driver.findElement(this.YearLabel).sendKeys(Year);
    }

    public void clickContinuarButton() {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.elementToBeClickable(continuarButton));
        Assert.assertEquals(driver.findElement(continuarButton).getText(), "Purchase");
        driver.findElement(continuarButton).click();
    }

    public void confirmarCompra() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.elementToBeClickable(aceptarBtn));
        Assert.assertEquals(driver.findElement(aceptarBtn).getText(), "OK");
        driver.findElement(aceptarBtn).click();
    }
    public CarritoCompras(WebDriver driver) {
        super(driver);
    }
}
