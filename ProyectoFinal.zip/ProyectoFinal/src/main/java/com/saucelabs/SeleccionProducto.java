package com.saucelabs;

import com.aventstack.extentreports.Status;
import com.saucelabs.helpers.ScreenShotHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class SeleccionProducto extends BasePagina{

    private final By nombreProductolbl= By.xpath("//a[contains(text(),'MacBook Pro')]");


    public SeleccionProducto(WebDriver driver) {
        super(driver);
    }
    public void Esperarcarga(){
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.elementToBeClickable(nombreProductolbl));
        Assert.assertEquals(driver.findElement(nombreProductolbl).getText(), "MacBook Pro");
        ScreenShotHelper.takeScreenShotAndAdToHTMLReport(driver, Status.INFO, "Laptops");
        driver.findElement(nombreProductolbl).click();

    }
    public String tomarProductoName(){
        return driver.findElement(nombreProductolbl).getText();
    }

}
