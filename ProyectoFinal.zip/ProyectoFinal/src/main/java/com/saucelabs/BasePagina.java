package com.saucelabs;

import org.openqa.selenium.WebDriver;

public class BasePagina {

        protected final WebDriver driver;

        public BasePagina(WebDriver driver) {
            this.driver = driver;
        }

}
