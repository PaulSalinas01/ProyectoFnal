package com.saucelabs;

import com.aventstack.extentreports.Status;
import com.saucelabs.helpers.ScreenShotHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MenuProducto extends BasePagina {

      private final By lapbtn = By.xpath("//a[@onclick=\"byCat('notebook')\"]");

    public MenuProducto(WebDriver driver) {
        super(driver);
    }
    public void clickLapbtn() {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("//*[@id=\"tbodyid\"]/div[1]/div/div/h4/a"), "Samsung galaxy s6"));
        ScreenShotHelper.takeScreenShotAndAdToHTMLReport(driver, Status.INFO, "Pagina Principal");
        driver.findElement(lapbtn).click();
    }

}
