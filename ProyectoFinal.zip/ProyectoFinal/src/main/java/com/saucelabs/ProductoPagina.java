package com.saucelabs;

import com.aventstack.extentreports.Status;
import com.saucelabs.helpers.ScreenShotHelper;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class ProductoPagina extends BasePagina{
    private final By addProductbtn = By.xpath("//div/a[@class='btn btn-success btn-lg']");
    private final By cartBtn = By.xpath("//a [@id='cartur']");

    public ProductoPagina(WebDriver driver) {
        super(driver);
    }

    public void agregarProducto() throws InterruptedException {


        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.elementToBeClickable(addProductbtn));
        Assert.assertEquals(driver.findElement(addProductbtn).getText(), "Add to cart");
        ScreenShotHelper.takeScreenShotAndAdToHTMLReport(driver, Status.INFO, "MacBook seleccionado");
        driver.findElement(addProductbtn).click();


        try {
            // Realiza las acciones que generan la alerta
            // Espera hasta que la alerta esté presente
            WebDriverWait waitAlert = new WebDriverWait(driver, 10);
            Alert alert = waitAlert.until(ExpectedConditions.alertIsPresent());
            System.out.println("Alerta detectada: " + alert.getText());
            alert.accept();

        } catch (UnhandledAlertException e) {
            System.out.println("Alerta no manejada: " + e.getAlertText());
            Alert alert = driver.switchTo().alert();
            alert.accept();
        }

        WebDriverWait waitCart = new WebDriverWait(driver, 10);
        waitCart.until(ExpectedConditions.elementToBeClickable(cartBtn));
        Assert.assertEquals(driver.findElement(cartBtn).getText(), "Cart");
        driver.findElement(cartBtn).click();



    }
}
