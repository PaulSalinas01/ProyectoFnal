import com.aventstack.extentreports.Status;
import com.saucelabs.CarritoCompras;
import com.saucelabs.MenuProducto;
import com.saucelabs.ProductoPagina;
import com.saucelabs.SeleccionProducto;
import com.saucelabs.helpers.ScreenShotHelper;
import org.testng.annotations.Test;

public class EjecucionPrueba extends BaseTest{
    @Test
    public void test() throws InterruptedException {
        MenuProducto menuPagina = new MenuProducto(driver);
        menuPagina.clickLapbtn();

        SeleccionProducto seleccion = new SeleccionProducto(driver);
        seleccion.Esperarcarga();

        ProductoPagina agregar = new ProductoPagina(driver);
        agregar.agregarProducto();
        ScreenShotHelper.takeScreenShotAndAdToHTMLReport(driver, Status.INFO, "Se ingresa pagina de carrito");

        CarritoCompras compras = new CarritoCompras(driver);
        compras.compraProducto();
        ScreenShotHelper.takeScreenShotAndAdToHTMLReport(driver, Status.INFO, "laptop en carrito");
        compras.llenadoFormulario("Paul", "Bolivia", "LaPaz","1111111","Enero", "2024");
        ScreenShotHelper.takeScreenShotAndAdToHTMLReport(driver, Status.INFO, "se llena formulario para compra");
        compras.clickContinuarButton();
        ScreenShotHelper.takeScreenShotAndAdToHTMLReport(driver, Status.INFO, "conformidad de la compra");
        compras.confirmarCompra();

    }
}
