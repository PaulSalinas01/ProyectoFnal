import com.aventstack.extentreports.Status;
import com.saucelabs.helpers.ReportManager;
import com.saucelabs.helpers.ScreenShotHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

public class BaseTest {

    protected WebDriver driver;

    private String browser = "chrome";

    private String url = "https://www.demoblaze.com/";

    @BeforeSuite
    public static void setupSuite() throws Exception {
        ReportManager.init("Reports", "ProyectoFinalAutomation");
    }


    @BeforeMethod
    public void setup(Method method) throws Exception {

        ReportManager.getInstance().startTest(method.getName());

        switch (browser) {
            case "chrome":
                System.setProperty("webdriver.chrome.driver", "resources/chromedriver.exe");
                driver = new ChromeDriver();
                break;
            case "firefox":
                System.setProperty("webdriver.gecko.driver","resources/geckodriver.exe");
                driver = new FirefoxDriver();
                break;
            default:
                throw new Exception(browser + " browser no soportado");
        }
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.get(url);
        ScreenShotHelper.takeScreenShotAndAdToHTMLReport(driver, Status.INFO, "Navegando en la pagina");
    }

    @AfterMethod
    public void tearDown() throws InterruptedException {
        if (driver != null)
            driver.quit();
    }

    @AfterSuite
    public static void tearDownSuite() {
        ReportManager.getInstance().flush();
    }
}
